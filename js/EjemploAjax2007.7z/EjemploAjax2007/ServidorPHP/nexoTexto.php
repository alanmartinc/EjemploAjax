<?php 
			sleep(2);
			include("partes/texto.php");

 ?>