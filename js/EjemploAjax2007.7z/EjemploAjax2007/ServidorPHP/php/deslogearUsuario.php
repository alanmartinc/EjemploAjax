<?php 
	session_start();
	$_SESSION['registrado']=null;
	session_destroy();

 ?>